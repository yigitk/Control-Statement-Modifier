package com.parse.samples;

public class Test {
	public static void main(String[] args) {
	}
}
