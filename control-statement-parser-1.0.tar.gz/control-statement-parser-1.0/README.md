# control-statement-parser

The program takes the input java file path as command line argument.
