package com.parse.models;

public enum OperandType {
	STRING, INTEGER, CHARACTER, ENUM, NONE;
}
